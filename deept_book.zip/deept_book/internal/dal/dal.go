package dal

import (
	"context"
	"database/sql"

	"github.com/deept14/users/deeptagarwal/kratos/project_book/cmd/deept_book/api/entities"

	_ "github.com/go-sql-driver/mysql"
)

// DAL represents the Data Access Layer.
type DAL struct {
	db *sql.DB
}

// NewDAL creates a new instance of the Data Access Layer.
func NewDAL(db *sql.DB) *DAL {
	return &DAL{db: db}
}

// CreateBook inserts a new book into the database.
func (d *DAL) CreateBook(ctx context.Context, book *entities.Book) (string, error) {
	_, err := d.db.ExecContext(ctx, "INSERT INTO books (title, author_id, publisher) VALUES (?, ?, ?)", book.Title, book.AuthorID, book.Publisher)
	if err != nil {
		return "", err
	}
	return "Book created successfully", nil
}

// GetBook retrieves a book from the database by its ID.
func (d *DAL) GetBook(ctx context.Context, id uint32) (*entities.Book, error) {
	var book entities.Book
	err := d.db.QueryRowContext(ctx, "SELECT id, title, author_id, publisher FROM books WHERE id = ?", id).
		Scan(&book.ID, &book.Title, &book.AuthorID, &book.Publisher)
	if err != nil {
		return nil, err
	}
	return &book, nil
}

// UpdateBook updates an existing book in the database.
func (d *DAL) UpdateBook(ctx context.Context, book *entities.Book) error {
	_, err := d.db.ExecContext(ctx, "UPDATE books SET title = ?, author_id = ?, publisher = ? WHERE id = ?", book.Title, book.AuthorID, book.Publisher, book.ID)
	if err != nil {
		return err
	}
	return nil
}

// DeleteBook deletes a book from the database by its ID.
func (d *DAL) DeleteBook(ctx context.Context, id uint32) error {
	_, err := d.db.ExecContext(ctx, "DELETE FROM books WHERE id = ?", id)
	if err != nil {
		return err
	}
	return nil
}
