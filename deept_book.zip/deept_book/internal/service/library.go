package service

import (
	"context"
	"github.com/go-kratos/kratos/v2/log"
	pb "library/api/library/v1"
)

// LibraryService is a service implementation for the Library service.
type LibraryService struct {
	pb.UnimplementedLibraryServer
	log *log.Helper
}

// NewLibraryService returns a new LibraryService instance.
func NewLibraryService(logger log.Logger) *LibraryService {
	return &LibraryService{log: log.NewHelper(logger)}
}

// Implement service methods...

